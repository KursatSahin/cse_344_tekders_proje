//
// Created by akursat on 31.08.2018.
//

#ifndef TEKDERS_UDPCLIENT_H
#define TEKDERS_UDPCLIENT_H

#endif //TEKDERS_UDPCLIENT_H

void checkUsage(int argc, char *argv[]);

void INThandler(int sig);

void *readServerThread(void *arg);