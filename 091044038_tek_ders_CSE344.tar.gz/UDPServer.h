//
// Created by akursat on 31.08.2018.
//

#ifndef TEKDERS_UDPSERVER_H
#define TEKDERS_UDPSERVER_H

void  INThandler(int sig);
void *thread_func(void *arg);

#endif //TEKDERS_UDPSERVER_H
